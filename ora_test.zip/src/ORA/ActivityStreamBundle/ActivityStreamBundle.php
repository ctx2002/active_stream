<?php
namespace ORA\ActivityStreamBundle;
use Symfony\Component\HttpKernel\Bundle\Bundle;

class ActivityStreamBundle extends Bundle
{
}
