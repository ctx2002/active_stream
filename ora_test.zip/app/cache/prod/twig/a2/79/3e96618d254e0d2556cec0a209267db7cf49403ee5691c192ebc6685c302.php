<?php

/* ActivityStreamBundle:Main:homepage.html.twig */
class __TwigTemplate_a2793e96618d254e0d2556cec0a209267db7cf49403ee5691c192ebc6685c302 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        echo "<a href=\"";
        echo $this->env->getExtension('routing')->getUrl("api_1_new_recipe");
        echo "\">create a recipe</a> <br />

<a href=\"";
        // line 4
        echo $this->env->getExtension('routing')->getUrl("api_1_get_activity_streams");
        echo "\">Show activity streams</a>";
    }

    public function getTemplateName()
    {
        return "ActivityStreamBundle:Main:homepage.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 4,  19 => 2,);
    }
}
