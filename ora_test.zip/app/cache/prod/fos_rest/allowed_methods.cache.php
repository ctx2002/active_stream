<?php return array (
  'fos_user_security_login' => 
  array (
    0 => 'GET',
    1 => 'POST',
  ),
  'fos_user_security_check' => 
  array (
    0 => 'POST',
  ),
  'fos_user_security_logout' => 
  array (
    0 => 'GET',
  ),
  'fos_user_profile_show' => 
  array (
    0 => 'GET',
  ),
  'fos_user_profile_edit' => 
  array (
    0 => 'GET',
    1 => 'POST',
  ),
  'fos_user_registration_register' => 
  array (
    0 => 'GET',
    1 => 'POST',
  ),
  'fos_user_registration_check_email' => 
  array (
    0 => 'GET',
  ),
  'fos_user_registration_confirm' => 
  array (
    0 => 'GET',
  ),
  'fos_user_registration_confirmed' => 
  array (
    0 => 'GET',
  ),
  'fos_user_resetting_request' => 
  array (
    0 => 'GET',
  ),
  'fos_user_resetting_send_email' => 
  array (
    0 => 'POST',
  ),
  'fos_user_resetting_check_email' => 
  array (
    0 => 'GET',
  ),
  'fos_user_resetting_reset' => 
  array (
    0 => 'GET',
    1 => 'POST',
  ),
  'fos_user_change_password' => 
  array (
    0 => 'GET',
    1 => 'POST',
  ),
  'nelmio_api_doc_index' => 
  array (
    0 => 'GET',
  ),
  'api_1_edit_recipe' => 
  array (
    0 => 'GET',
  ),
  'api_1_new_recipe' => 
  array (
    0 => 'GET',
  ),
  'api_1_put_recipe' => 
  array (
    0 => 'PUT',
    1 => 'GET',
  ),
  'api_1_get_recipe' => 
  array (
    0 => 'PUT',
    1 => 'GET',
  ),
  'api_1_post_recipe' => 
  array (
    0 => 'POST',
  ),
  'api_1_get_activity_streams' => 
  array (
    0 => 'GET',
  ),
);